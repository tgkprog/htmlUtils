import { Component, OnInit, ViewEncapsulation, ElementRef, ViewChild, AfterViewInit  } from '@angular/core';
 
@Component({
	selector: 'app-aboutus-component',
	templateUrl: './aboutus-component.html',
	styleUrls:  ['./aboutus-component.css'],
})
export class AboutusComponent {

	

}