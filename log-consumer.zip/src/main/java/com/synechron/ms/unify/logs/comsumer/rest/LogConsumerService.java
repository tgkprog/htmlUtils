package com.synechron.ms.unify.logs.comsumer.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LogConsumerService.class);

    @RequestMapping(value = "/logconsumer", method = RequestMethod.GET)
    public String consumerLogInformation(@RequestParam(name="log_host", required = false) final String logHost,
    									@RequestParam(name="log_app", required = false) final String logApp,
    									@RequestParam(name="log_timestamp", required = false) final String logTimestamp,
                                       @RequestParam(name="log_level", required = false) final String logLevel,
                                       @RequestParam(name="log_thread", required = false) final String logThread,
                                       @RequestParam(name="log_location", required = false) final String logLocation,
                                       @RequestParam(name="log_message", required = false) final String logMessage,
                                       @RequestParam(name="stacktrace", required = false) final String stacktrace,
                                       @RequestParam(name="uncategorized_log", required = false) final String uncategorizedLog) {

        if (logTimestamp != null) {
            LOGGER.info(String.format("HOST: %s, APP: %s, TIMESTAMP: %s, LEVEL: %s, THREAD: %s, LOCATION: %s, MESSAGE: %s",
                    logHost, logApp, logTimestamp, logLevel, logThread, logLocation, logMessage));
        } else if (stacktrace != null) {
            LOGGER.info(String.format("HOST: %s, APP: %s, STACKTRACE: %s", logHost, logApp, stacktrace));
        } else if (uncategorizedLog != null) {
            LOGGER.info(String.format("HOST: %s, APP: %s, UNCATEGORIZED LOG: %s", logHost, logApp, uncategorizedLog));
        } else {
            LOGGER.info("Oops!! invalid request recieved");
            return "Not supported";
        }
        return "OK";
    }




}
