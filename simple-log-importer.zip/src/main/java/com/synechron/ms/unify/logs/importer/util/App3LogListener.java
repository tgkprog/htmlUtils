package com.synechron.ms.unify.logs.importer.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import static com.synechron.ms.unify.logs.importer.util.AppProperties.*;

public class App3LogListener implements ParsedLogEventListener {
	
	private static final Logger LOGGER = Logger.getLogger(App3LogListener.class);
	
	private static final String APP3_LOG_CONSUMER_URL = String.format(
			getListenerApp3Url() + "?log_host=%s&log_app=%s", 
			getTargetHostname(), getTargetApp());

	@Override
	public void onParsedLogEvent(Map<String, String> logInfo) {
		
		LOGGER.debug("Sending log information: " + logInfo);
		
		try {
			final String uploadRequest = APP3_LOG_CONSUMER_URL + ( logInfo.isEmpty() ? "" : "&" + 
				String.join("&", logInfo.entrySet()
										.stream()
										.map(e -> {
												try {
													return mapToApp3Key(e.getKey())+"="+ URLEncoder.encode(e.getValue(), "UTF-8");
												} catch (final UnsupportedEncodingException ex) {
													throw new RuntimeException(String.format("Failed to encode log info value '%s'", e.getValue()), ex);
												}
											})
										.collect(Collectors.toList())
										));
			
			final URL obj = new URL(uploadRequest);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	
			// optional default is GET
			con.setRequestMethod("GET");
	
			//add request header
			//con.setRequestProperty("User-Agent", USER_AGENT);
	
			int responseCode = con.getResponseCode();
			LOGGER.debug("\nSending 'GET' request to URL : " + uploadRequest);
			LOGGER.debug("Response Code : " + responseCode);
	
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
	
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
	
			//print result
			LOGGER.info(response.toString());
		} catch (final IOException e) {
			LOGGER.error("Failed to upload log information to APP3", e);
		}
	}
	
	private String mapToApp3Key(final String logInfoKey) {
		
		switch (logInfoKey) {
		case "TIMESTAMP"	: return "log_timestamp";
		case "LEVEL"		: return "log_level";
		case "THREAD"		: return "log_thread";
		case "LOCATION"		: return "log_location";
		case "MESSAGE"		: return "log_message";
		case "STACKTRACE"	: return "stacktrace";
		default				: return "uncategorized_log";		
		}
	}

}
