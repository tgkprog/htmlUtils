package com.synechron.ms.unify.logs.importer.util;

import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;

import java.io.IOException;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.String.format;
import static com.synechron.ms.unify.logs.importer.util.AppProperties.*;

/**
 * {@link ParsedLogEventListener} implementation for Solr. It uploads log information to solr collection for indexing.
 * It makes use of SolrJ client APIs. It can upload log information in batch to improve performance. Batch capacity and
 * maximum time to wait to commit are configurable properties through app.properties.
 */
public class SolrLogListener implements ParsedLogEventListener {

    private static final Logger LOGGER = Logger.getLogger(SolrLogListener.class);

    private final String serverUrl;
    private final SolrClient solrClient;

    private final long batchCapacity;
    private final long maxTimeToCommit;

    private AtomicInteger currentBatchSize = new AtomicInteger(0);

    private final Timer timer = new Timer(true);

    private class ScheduledCommitTask extends TimerTask {

        private final Logger logger = Logger.getLogger(ScheduledCommitTask.class);

        @Override
        public void run() {
            logger.debug("committing pending changes if any");
            commit();
        }
    }

    public SolrLogListener(final String solrUrl) {
        this.serverUrl = solrUrl;
        this.solrClient = new HttpSolrClient.Builder(solrUrl).build();
        this.batchCapacity = getListenerSolrBatchCapacity(500);
        this.maxTimeToCommit = getListenerSolrBatchCommitIntervalMillisec(10000);
        timer.scheduleAtFixedRate(new ScheduledCommitTask(), 0, maxTimeToCommit);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("committing pending changes if any before shutdown");
            commit();
        }));
    }

    @Override
    public void onParsedLogEvent(final Map<String, String> logInfo) {
        final SolrInputDocument document = new SolrInputDocument();
        //populate logging event information into document
        document.addField("log_host", getTargetHostname());
        document.addField("log_app", getTargetApp());
        //TODO: handle unknown components
        if (logInfo.containsKey("TIMESTAMP")) {
            document.addField("log_timestamp", logInfo.get("TIMESTAMP"));
            document.addField("log_level", logInfo.get("LEVEL"));
            document.addField("log_thread", logInfo.get("THREAD"));
            document.addField("log_location", logInfo.get("LOCATION"));
            document.addField("log_message", logInfo.get("MESSAGE"));
        } else if (logInfo.containsKey("STACKTRACE")) {
            document.addField("stacktrace", logInfo.get("STACKTRACE"));
        } else {
            document.addField("uncategorized_log", logInfo.get("UNCATEGORIZED"));
        }

        //send document to Solr
        try {
            solrClient.add(document);
            currentBatchSize.incrementAndGet();

            if (currentBatchSize.get() >= batchCapacity) {
                commit();
            }
        } catch (final IOException | SolrServerException e) {
            LOGGER.error("Failed to send logging event information to Solr Server: " + serverUrl, e);
        }
    }

    private void commit() {
        if(currentBatchSize.get() > 0) {
            LOGGER.info("Committing solr entries: " + currentBatchSize);

            try {
                solrClient.commit();
            } catch (final IOException | SolrServerException e) {
                LOGGER.error(format("Error occurred while committing log information to Solr(%s): %s", serverUrl, e.getMessage()), e);
            }

            currentBatchSize.set(0);

        } else {
            LOGGER.info("Nothing to commit");
        }
    }

}
