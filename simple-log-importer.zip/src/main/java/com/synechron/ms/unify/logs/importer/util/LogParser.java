package com.synechron.ms.unify.logs.importer.util;

import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Utility class that parses set of log statements or a log file, and passes that information to registered listener.
 * A listener is called per extraction of log statement, stacktrace and uncategorized log statement. It needs log
 * statement format, timestamp format in order to parse log statements. It assumes that stacktrace is continuous i.e
 * no other logs appear in between stacktrace lines, otherwise each part of stacktrace is recognized as separate
 * STACKTRACE information. Log information is generated in the form of map i.e. key-value pair and passed to listener.
 * Keys of map are the tokens retrieved from log statement format and values are parsed matching contents from log
 * statements. For stacktrace, key is 'STACKTRACE' while value is {@link List} of strings. For any other unparsed log
 * statement, key is 'UNCATEGORIZED'.
 */
public class LogParser {

    private static final Logger LOGGER = Logger.getLogger(LogParser.class);

    private final String timestampFormat;
    private final String [] components;
    private final String [] splitters;
    private final ParsedLogEventListener eventListener;

    /**
     * Initialized {@link LogParser} with log statement format, timestamp format and a listener.
     * @param logFormat
     * @param timestampFormat
     * @param listener
     */
    public LogParser(final String logFormat, final String timestampFormat, final ParsedLogEventListener listener) {
        this.timestampFormat = timestampFormat;
        this.eventListener = listener;

        LOGGER.info("LOG FORMAT: " + logFormat);
        LOGGER.info("TIMESTAMP FORMAT: " + timestampFormat);

        components = logFormat.split("[^a-zA-Z]+");
        Arrays.stream(components).forEach(component -> LOGGER.info("Component: '" + component + "'"));
        splitters = logFormat.split("[a-zA-Z]+");
        Arrays.stream(splitters).forEach(splitter -> LOGGER.info("Splitter: '" + splitter + "'"));
    }

    /**
     * Reads file at once into list of strings and then processed.
     * @param logFile
     * @throws IOException
     */
    public void parseLogFile(final File logFile) throws IOException {
        //TODO: If file is too large, chunk processing is required
        parseLogs(Files.readAllLines(logFile.toPath()));
    }

    public void parseLogs(final List<String> logs) {

        final List<String> uncategorizedLogs = new ArrayList<>();

        LOGGER.info("Number of logs: " + logs.size());

        long logCount = 0;

        for (String log : logs) {
            logCount++;

            final String originalLog = log;
            LOGGER.debug("Log line: " + originalLog);
            LOGGER.debug("Logs processed: " + logCount);
            final Map<String, String> event = new HashMap<>();

            for (int i = 0; i < components.length; i++) {
                LOGGER.debug("Component: '" + components[i] + "'");
                LOGGER.debug("Splitter: '" + splitters[i] + "'");
                final String regexPrefix = splitters[i];
                final String regexSuffix = i == (components.length - 1) ? "" : splitters[i+1];
                final String regex = escapeRegexChars(regexPrefix) +
                        getComponentRegex(components[i], i == (components.length - 1)) +
                        escapeRegexChars(regexSuffix);
                LOGGER.debug("Regex: '"+regex+"'");
                final Pattern pattern = Pattern.compile(regex);
                final Matcher matcher = pattern.matcher(log);
                if (matcher.find()) {
                    String actual = matcher.group(0);
                    LOGGER.debug("actual-1: " + actual);
                    actual = actual.substring(regexPrefix.length(), actual.length() - regexSuffix.length());
                    //trim spaces around if any - generally LEVEL info is suffixed with spaces
                    actual = actual.trim();
                    LOGGER.debug("actual-2: " + actual);
                    if ( i < components.length) {
                        log = log.substring(regexPrefix.length() + actual.length());
                    }
                    LOGGER.debug(components[i] + ": '"+actual+"'");
                    event.put(components[i], actual);
                } else {
                    uncategorizedLogs.add(originalLog);
                    //LOGGER.warn("Uncategorized event: " + originalLog);
                    event.clear();
                    break;
                }
                LOGGER.debug("New log: " + log);
            }

            if (!event.isEmpty()) {

                if (!uncategorizedLogs.isEmpty()) {
                    handleUncategorizedLogs(uncategorizedLogs);
                    uncategorizedLogs.clear();
                }
                handleLogEvent(event);
            }

        }

        if (!uncategorizedLogs.isEmpty()) {
            handleUncategorizedLogs(uncategorizedLogs);
            uncategorizedLogs.clear();
        }
    }

    private void handleLogEvent(final Map<String, String> logInfo) {
        logInfo.entrySet().stream().forEach(e -> LOGGER.debug(e.getKey() + " -> " + e.getValue()));
        eventListener.onParsedLogEvent(logInfo);
    }


    private void handleUncategorizedLogs(final List<String> uncategorizedLogs) {
        final List<String> stackTrace = new ArrayList<>();

        for (int i = 0; i < uncategorizedLogs.size(); i++) {
            if (uncategorizedLogs.get(i).startsWith("\tat")) {
                if (i > 0) {
                    stackTrace.add(uncategorizedLogs.get(i-1));
                }
                while (i < uncategorizedLogs.size() && uncategorizedLogs.get(i).startsWith("\tat")) {
                    stackTrace.add(uncategorizedLogs.get(i++));
                }
                LOGGER.debug("STACKTRACE found: ");
                stackTrace.forEach(trace -> LOGGER.debug(trace));
                eventListener.onParsedLogEvent(mapOf("STACKTRACE", String.join("\n\t", stackTrace)));
            } else if (i == uncategorizedLogs.size() - 1 || !uncategorizedLogs.get(i+1).startsWith("\tat")) {
                LOGGER.debug("Uncategorized log statement: " + uncategorizedLogs.get(i));
                eventListener.onParsedLogEvent(mapOf("UNCATEGORIZED", uncategorizedLogs.get(i)));
            }
        }
    }

    private Map<String, String> mapOf(final String k1, final String v1) {
        final Map<String, String> map = new HashMap<>(1);
        map.put(k1, v1);
        return Collections.unmodifiableMap(map);
    }

    private String getComponentRegex(final String component, final boolean isLastComponent) {
        return  ("TIMESTAMP".equals(component) ?
                "(" + timestampFormat.replaceAll("[a-zA-Z]+", "\\\\w+") + ")":
                isLastComponent ?
                        "(.*)" : "(.*?)" );
    }

    private String escapeRegexChars(final String string) {
        final Pattern specialRegexChars = Pattern.compile("[{}()\\[\\].+*?^$\\\\|]");
        return specialRegexChars.matcher(string).replaceAll("\\\\$0");
    }
}
