package com.synechron.ms.unify.logs.importer.util;

import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.synechron.ms.unify.logs.importer.util.AppProperties.*;
import static java.lang.String.format;
import static java.nio.file.StandardWatchEventKinds.*;

/**
 * It is processing unit for parsing of log file. It validates log file name against configured application property
 * and then parse asynchronously. It also listens to log information extracted by {@link LogParser} and then pass it to
 * {@link ParsedLogEventListener}s asynchronously. After parsing log file, if no parsing error reported, it is moved to
 * success directory otherwise moved to failure directory. Success directory and failure directory locations are
 * configurable properties through app.properties.
 *
 * Note, moving file to success directory or failure directory is solely based on parsing process, any error while
 * handling extracted log information is not considered.
 */
public class LogFileProcessor implements ParsedLogEventListener, DirectoryChangeListener {

    private static final Logger LOGGER = Logger.getLogger(LogFileProcessor.class);

    private final ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    private final List<ParsedLogEventListener> eventListeners = new ArrayList<>();

    private final LogParser logParser;

    private final File successDir;

    private final File failureDir;

    private class LogFileParserTask implements Callable<Void> {

        private final Logger logger = Logger.getLogger(LogFileParserTask.class);

        private final File file;

        LogFileParserTask(final File file) {
            this.file = file;
        }

        @Override
        public Void call() {
            final long startTime = System.currentTimeMillis();
            try {
                logger.info(format("Processing file %s in separate thread", file));
                logParser.parseLogFile(file);
                logger.info(format("Finished processing file, moving to success directory, %s", file));
                file.renameTo(new File(successDir, file.getName()));
            } catch (final Throwable t) {
                logger.error(format("Failed to process file, moving to failure directory %s", file), t);
                file.renameTo(new File(failureDir, file.getName()));
            }
            final long endTime = System.currentTimeMillis();
            LOGGER.info(format("Total time to process file %s is %d ms", file, (endTime - startTime)));
            return null;
        }
    }


    private class LogEventHandlerTask implements Callable<Void> {

        private final Logger logger = Logger.getLogger(LogEventHandlerTask.class);

        private final List<ParsedLogEventListener> eventListeners;
        private final Map<String, String> logInfo;

        LogEventHandlerTask(final List<ParsedLogEventListener> eventListeners, final Map<String, String> logInfo) {
            this.eventListeners = eventListeners;
            this.logInfo = logInfo;
        }

        @Override
        public Void call() {
            eventListeners.stream().forEach(logEventListener -> {
                try {
                    logEventListener.onParsedLogEvent(logInfo);
                } catch (final Exception e) {
                    logger.error(format("Log event listener %s failed to process log information: %s",
                            logEventListener, e.getMessage()), e);
                }
            });
            return null;
        }
    }

    public LogFileProcessor(final ParsedLogEventListener... eventListeners) throws IOException {
        this.successDir = new File(getTargetSuccessDir());
        this.failureDir = new File(getTargetFailureDir());
        Files.createDirectories(successDir.toPath());
        Files.createDirectories(failureDir.toPath());

        LOGGER.info("Success directory: " + successDir.getAbsolutePath());
        LOGGER.info("Failure directory: " + failureDir.getAbsolutePath());

        this.logParser  = new LogParser(getTargetInputFileLogFormat(),
                getTargetInputFileTimestampPattern(), this);
        Arrays.stream(eventListeners).forEach(listener -> this.eventListeners.add(listener));
    }


    public void processAllFilesInDir(final File directory, final boolean watchForNewFiles) throws Exception {
        if (!directory.exists() || !directory.isDirectory()) {
            LOGGER.error(format("Target input directory %s either does not exists or is not a directory", directory));
            System.exit(1);
        }

        final File [] files = directory.listFiles();

        if (watchForNewFiles) {
            watchDirectory(directory);
        }

        Arrays.stream(files).forEach(logFile -> process(logFile));
    }

    private void watchDirectory(final File directory) throws Exception {
        DirectoryWatchService.watch(directory, this);
    }

    @Override
    public void onDirectoryChange(final File directory, final WatchEvent<?> changeEvent) throws Exception {
        final WatchEvent.Kind kind = changeEvent.kind();
        final Object context = changeEvent.context();
        if (kind == ENTRY_CREATE) {
            LOGGER.info("Found new file: " + context);
            final Path newFilePath = Paths.get(directory.toPath().toString(), context.toString());
            process(newFilePath.toFile());
        }
    }

    public void process(final File logFile) {
        if (logFile.exists() && logFile.isFile()) {
            if(logFile.getName().matches(AppProperties.getTargetInputFileNamePattern())) {
                LOGGER.info("Processing file: " + logFile);
                executorService.submit(new LogFileParserTask(logFile));
            } else {
                LOGGER.warn(String.format("skipping file '%s' as it name does not match name pattern", logFile));
            }
        } else {
            LOGGER.warn("File does not exists or is not a file: " + logFile);
        }
    }

    @Override
    public void onParsedLogEvent(final Map<String, String> logInfo) {
        LOGGER.debug("Handling log info: " + logInfo);
        executorService.submit(new LogEventHandlerTask(eventListeners, logInfo));
    }
}

