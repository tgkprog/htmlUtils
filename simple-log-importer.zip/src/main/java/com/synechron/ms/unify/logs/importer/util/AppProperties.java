package com.synechron.ms.unify.logs.importer.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Utility class with all static methods for reading application properties.
 */
public class AppProperties {

    private static final String PROPS_FILE_NAME = "app.properties";

    private static final Properties PROPS = new Properties();

    static {
        try {
            PROPS.load(AppProperties.class.getClassLoader().getResourceAsStream(PROPS_FILE_NAME));
        } catch (final IOException e) {
            System.err.println("Failed to load properties, error: " + e.getMessage());
        }
    }


    //properties keys

    private static final String KEY_TARGET_HOST = "target.host.name";
    private static final String KEY_TARGET_APP = "target.app.name";
    private static final String KEY_TARGET_INPUT_DIR = "target.input.dir";
    private static final String KEY_TARGET_INPUT_FILE_NAME_PATTERN = "target.input.file.name.pattern";
    private static final String KEY_TARGET_INPUT_FILE_LOG_FORMAT = "target.input.file.log.pattern";
    private static final String KEY_TARGET_INPUT_FILE_TIMESTAMP_PATTERN = "target.input.file.TIMESTAMP.pattern";
    private static final String KEY_TARGET_SUCCESS_DIR  = "target.success.dir";
    private static final String KEY_TARGET_FAILURE_DIR = "target.failure.dir";

    private static final String KEY_LISTENER_SOLR_DOC_URL = "listener.solr.doc.url";
    private static final String KEY_LISTENER_SOLR_BATCH_CAPACIY = "listener.solr.batch.capacity";
    private static final String KEY_LISTENER_SOLR_BATCH_COMMIT_INTERVAL_MILLISEC = "listener.solr.batch.commit.interval.millisec";

    private static final String KEY_LISTENER_APP3_URL = "listener.app3.url";
    
    public static String getTargetHostname() {
        return PROPS.getProperty(KEY_TARGET_HOST);
    }

    public static String getTargetApp() {
        return PROPS.getProperty(KEY_TARGET_APP);
    }

    public static String getTargetInputDir() {
        return PROPS.getProperty(KEY_TARGET_INPUT_DIR);
    }

    public static String getTargetInputFileNamePattern() {
        return PROPS.getProperty(KEY_TARGET_INPUT_FILE_NAME_PATTERN);
    }

    public static String getTargetInputFileLogFormat() {
        return PROPS.getProperty(KEY_TARGET_INPUT_FILE_LOG_FORMAT);
    }

    public static String getTargetInputFileTimestampPattern() {
        return PROPS.getProperty(KEY_TARGET_INPUT_FILE_TIMESTAMP_PATTERN);
    }

    public static String getTargetSuccessDir() {
        return PROPS.getProperty(KEY_TARGET_SUCCESS_DIR);
    }

    public static String getTargetFailureDir() {
        return PROPS.getProperty(KEY_TARGET_FAILURE_DIR);
    }

    public static String getListenerSolrDocUrl() {
        return PROPS.getProperty(KEY_LISTENER_SOLR_DOC_URL);
    }

    public static long getListenerSolrBatchCapacity(long defaultCapacity) {
        return PROPS.containsKey(KEY_LISTENER_SOLR_BATCH_CAPACIY) ?
                Long.parseLong(PROPS.getProperty(KEY_LISTENER_SOLR_BATCH_CAPACIY)) :
                defaultCapacity;
    }

    public static Long getListenerSolrBatchCommitIntervalMillisec(final long defaultInterval) {
        return PROPS.containsKey(KEY_LISTENER_SOLR_BATCH_COMMIT_INTERVAL_MILLISEC) ?
                Long.parseLong(PROPS.getProperty(KEY_LISTENER_SOLR_BATCH_COMMIT_INTERVAL_MILLISEC)) :
                defaultInterval;
    }
    
    public static String getListenerApp3Url() {
		return PROPS.getProperty(KEY_LISTENER_APP3_URL);
	}

    public static void main(String[] args) {
        System.out.println(getTargetApp());
    }

}
