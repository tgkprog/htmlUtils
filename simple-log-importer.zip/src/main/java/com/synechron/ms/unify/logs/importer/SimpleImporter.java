package com.synechron.ms.unify.logs.importer;

import com.synechron.ms.unify.logs.importer.util.*;
import org.apache.log4j.Logger;

import java.io.File;

import static com.synechron.ms.unify.logs.importer.util.AppProperties.*;
import static java.lang.String.format;

public class SimpleImporter {

    private static final Logger LOGGER = Logger.getLogger(SimpleImporter.class);

    public static void main(String[] args) throws Exception {

        LOGGER.info("Import started for input directory: " + getTargetInputDir());

        final File targetInputDir = new File(getTargetInputDir());

        final ParsedLogEventListener solrListener = new SolrLogListener(getListenerSolrDocUrl());
        final App3LogListener app3LogListener = new App3LogListener();
        
        final LogFileProcessor logFileProcessor = new LogFileProcessor(solrListener, app3LogListener);
        logFileProcessor.processAllFilesInDir(targetInputDir, true);

    }
}
