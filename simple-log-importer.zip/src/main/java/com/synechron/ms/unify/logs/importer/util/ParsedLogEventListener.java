package com.synechron.ms.unify.logs.importer.util;

import java.util.Map;


/**
 * An listener interface to consume parsed log information.
 */
public interface ParsedLogEventListener {

    /**
     * Accepts log information as a map of string keys and string values. Keys are expected to be log format tokens
     * like TIMESTAMP, LEVEL, THREAD, LOCATION, MESSAGE, STACKTRACE, UNCATEGORIZED etc. It is implementers choice to
     * simply consume info or construct meaningful object from logInfo and process it.
     * @param logInfo
     */
    public void onParsedLogEvent(final Map<String, String> logInfo);
}
