package com.synechron.ms.unify.logs.importer.util;

import org.apache.log4j.Logger;

import java.io.File;
import java.nio.file.*;

import static java.nio.file.StandardWatchEventKinds.*;

public class DirectoryWatchService {

    private static final Logger LOGGER = Logger.getLogger(DirectoryWatchService.class);

    public static void watch(final File targetDir, final DirectoryChangeListener listener) throws Exception {
        LOGGER.info("watching target directory: " + targetDir);
        final WatchService watchService = targetDir.toPath().getFileSystem().newWatchService();
        targetDir.toPath().register(watchService, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);


        //start a thread to listen events
        new Thread(() -> {
                while (true) {
                    try {
                        final WatchKey watchKey = watchService.take();
                        for (final WatchEvent<?> watchEvent : watchKey.pollEvents()) {
                            listener.onDirectoryChange(targetDir, watchEvent);
                        }

                        if (!watchKey.reset()) {
                            LOGGER.error("Target directory is not available: " + targetDir);
                            break;
                        }
                    } catch (final Exception e) {
                        LOGGER.error("Error occurred while processing directory change event: " + e.getMessage(), e);
                        //TODO: should app exit now?
                    }
                }
            }
        ).start();

    }
}
