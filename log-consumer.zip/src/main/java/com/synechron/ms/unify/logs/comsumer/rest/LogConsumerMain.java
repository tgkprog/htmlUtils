package com.synechron.ms.unify.logs.comsumer.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogConsumerMain {


    public static void main(String[] args) {
        SpringApplication.run(LogConsumerMain.class, args);
    }
}
