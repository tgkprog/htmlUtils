package com.synechron.ms.unify.logs.importer.util;

import java.io.File;
import java.nio.file.WatchEvent;

public interface DirectoryChangeListener {

    public void onDirectoryChange(final File directory, WatchEvent<?> changeEvent) throws Exception;
}
